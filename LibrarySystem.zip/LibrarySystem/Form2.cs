﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibrarySystem
{
    public partial class Form2 : Form
    {
        SqlConnection conn = new SqlConnection(@"server = .\SQLEXPRESS; database = LMS; Integrated Security = true");
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void btnSign_Click(object sender, EventArgs e)
        {
            Hide();
            Form4 f4 = new Form4();
            f4.Show();
        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        void FilldataGridView3()
        {
            if (conn.State == ConnectionState.Closed)
                conn.Open();
            SqlDataAdapter sqlda = new SqlDataAdapter("searchCustomer", conn);

            sqlda.SelectCommand.CommandType = CommandType.StoredProcedure;

            sqlda.SelectCommand.Parameters.AddWithValue("@BookId", txtS2.Text.Trim());


            DataTable tbl = new DataTable();
            sqlda.Fill(tbl);

            dataGridView3.DataSource = tbl;
            //dataGridView1.Columns[0].Visible = true;

            conn.Close();
        }


        private void dataGridView3_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                FilldataGridView3();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error message");
            }
        }
    }
}
