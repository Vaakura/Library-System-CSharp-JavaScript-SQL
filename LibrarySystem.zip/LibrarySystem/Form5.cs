﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibrarySystem
{
    public partial class Form5 : Form
    {
        SqlConnection conn = new SqlConnection(@"server = .\SQLEXPRESS; database = LMS; Integrated Security = true");
        public Form5()
        {
            InitializeComponent();
        }

        private void panel9_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

                SqlCommand command = new SqlCommand("InsertBook", conn);

                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Add(new SqlParameter("book_Id", SqlDbType.Int));
                command.Parameters["book_Id"].Value = txtBook.Text;

                command.Parameters.Add(new SqlParameter("barCode", SqlDbType.NVarChar));
                command.Parameters["barCode"].Value = txtBarCode.Text;

                command.Parameters.Add(new SqlParameter("bookTitle", SqlDbType.NVarChar));
                command.Parameters["bookTitle"].Value = txtBookTitle.Text;

                command.Parameters.Add(new SqlParameter("author", SqlDbType.NVarChar));
                command.Parameters["author"].Value = txtAuthor.Text;

                command.Parameters.Add(new SqlParameter("price", SqlDbType.Money));
                command.Parameters["price"].Value = txtPrice.Text;



                conn.Open();
                command.ExecuteNonQuery();


                MessageBox.Show("The book has been succesfully added");

            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex);

            }
            finally
            {
                conn.Close();
            }
        }

        private void btnSign_Click(object sender, EventArgs e)
        {
            Hide();
            Form4 f4 = new Form4();
            f4.Show();
        }

        void FilldataGridView2()
        {
            if (conn.State == ConnectionState.Closed)
                conn.Open();
            SqlDataAdapter sqlda = new SqlDataAdapter("searchBook", conn);

            sqlda.SelectCommand.CommandType = CommandType.StoredProcedure;

            sqlda.SelectCommand.Parameters.AddWithValue("@barCode", txtS7.Text.Trim());


            DataTable tbl = new DataTable();
            sqlda.Fill(tbl);

            dataGridView2.DataSource = tbl;
            //dataGridView1.Columns[0].Visible = true;

            conn.Close();


        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                FilldataGridView2();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error message");
            }

        }
    }
}
