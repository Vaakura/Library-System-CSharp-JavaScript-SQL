﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibrarySystem
{
    public partial class Form4 : Form
    {
        SqlConnection conn = new SqlConnection(@"server = .\SQLEXPRESS; database = LMS; Integrated Security = true");

     
 

        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Hide();
            Form1 F1 = new Form1();
            F1.Show();
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

       
        private void txtSrchBook_TextChanged(object sender, EventArgs e)
        {
   
        }
            

        private void btnBorrow_Click(object sender, EventArgs e)
        {
            
            try
            {

        

                    SqlCommand command = new SqlCommand("InsertCB", conn);

                    command.CommandType = CommandType.StoredProcedure;


                    command.Parameters.Add(new SqlParameter("BookId", SqlDbType.Int));
                    command.Parameters["BookId"].Value = txtBookId.Text;


                    command.Parameters.Add(new SqlParameter("BarCode", SqlDbType.NVarChar));
                    command.Parameters["BarCode"].Value = txtBarCode.Text;


                    command.Parameters.Add(new SqlParameter("BookTitle", SqlDbType.NVarChar));
                    command.Parameters["BookTitle"].Value = txtBookTitle.Text;

                    command.Parameters.Add(new SqlParameter("Author", SqlDbType.NVarChar));
                    command.Parameters["Author"].Value = txtAuthor.Text;

                    command.Parameters.Add(new SqlParameter("DateBorrowed", SqlDbType.DateTime));
                    command.Parameters["DateBorrowed"].Value = dtp1.Text;

                    command.Parameters.Add(new SqlParameter("price", SqlDbType.Money));
                    command.Parameters["price"].Value = txtPrice.Text;



                    command.Parameters.Add(new SqlParameter("NumberOfDays", SqlDbType.Int));
                    command.Parameters["NumberOfDays"].Value = txtNOD.Text;


                    command.Parameters.Add(new SqlParameter("DateDueBack", SqlDbType.DateTime));
                    command.Parameters["DateDueBack"].Value = dtp3.Text;
                  





                    conn.Open();
                    command.ExecuteNonQuery();

                    MessageBox.Show("Your Query has been processed Succesfully");

                
      
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(""+ex);
               
            }
            finally
            {
                conn.Close();
            }
        }

        void FilldataGridView1()
        {
            if (conn.State == ConnectionState.Closed)
                conn.Open();
            SqlDataAdapter sqlda = new SqlDataAdapter("search", conn); 

            sqlda.SelectCommand.CommandType = CommandType.StoredProcedure;

            sqlda.SelectCommand.Parameters.AddWithValue("@BarCode", txtSrchBook.Text.Trim());
  

            DataTable tbl = new DataTable();
            sqlda.Fill(tbl);

            dataGridView1.DataSource = tbl;
            //dataGridView1.Columns[0].Visible = true;

            conn.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
                 try
            {
                FilldataGridView1();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error message");
            }

        }

        private void txtDDB_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
         


            if (dataGridView1.CurrentRow.Index != -1)
            {
                int txtBookId =Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
           

                txtBarCode.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();

                txtBookTitle.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();

                txtAuthor.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();

                txtPrice.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();

                DateTime dtp1 = Convert.ToDateTime(dataGridView1.CurrentRow.Cells[5].Value.ToString());


                txtNOD.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();

               
             

                DateTime dtp3 = Convert.ToDateTime(dataGridView1.CurrentRow.Cells[7].Value.ToString());

                btnBorrow.Text = "Update";
                btnDelete.Enabled = true;

            }

        }

        private void txtBookId_TextChanged(object sender, EventArgs e)
        {

        }

        }

        }

   

