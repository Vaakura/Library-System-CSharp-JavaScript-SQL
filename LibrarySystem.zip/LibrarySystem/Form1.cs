﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace LibrarySystem
{
    public partial class Form1 : Form
    {

        SqlConnection conn = new SqlConnection(@"server = .\SQLEXPRESS; database = LMS; Integrated Security = true");
        public Form1()
        {
            InitializeComponent();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {


       
            
        }

        private void btnSign_Click(object sender, EventArgs e)
        {
                        SqlConnection conn = new SqlConnection(@"server = .\SQLEXPRESS; database = LMS; Integrated Security = true");

            try
            {
                conn.Open();
                string query = "select * from librarian where username = '" + txtUser.Text + "' and password= '" + txtPass.Text+ "'";
                SqlCommand cmd = new SqlCommand(query, conn);

                SqlDataReader r = cmd.ExecuteReader();
                int a = 0;
                while (r.Read())
                {
                    a = 1;
                }

                if (a == 1)
                {


                   

                    
                   MessageBox.Show("Successfully Signed In");
                   Hide();
                    new Form3().Show();
                }
                else
                {
                    MessageBox.Show("Incorrect username or password");
                }



            }
            catch(Exception ex)
            {
                MessageBox.Show(""+ex);
            }
            finally
            {
                conn.Close();
            }
        }

        private void btnExt_Click(object sender, EventArgs e)
        {

            Application.Exit();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        }

    }

