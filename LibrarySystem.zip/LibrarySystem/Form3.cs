﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibrarySystem
{
    public partial class Form3 : Form
    {
        SqlConnection conn = new SqlConnection(@"server = .\SQLEXPRESS; database = LMS; Integrated Security = true");
        public Form3()
        {

            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

                SqlCommand command = new SqlCommand("InsertCustomer", conn);

                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Add(new SqlParameter("customerId", SqlDbType.Int));
                command.Parameters["customerId"].Value = txtCustId.Text;

                command.Parameters.Add(new SqlParameter("Name", SqlDbType.NVarChar));
                command.Parameters["Name"].Value = txtName.Text;

                command.Parameters.Add(new SqlParameter("Surname", SqlDbType.NVarChar));
                command.Parameters["Surname"].Value = txtSurname.Text;

                command.Parameters.Add(new SqlParameter("DOB", SqlDbType.Date));
                command.Parameters["DOB"].Value = dtp5.Text;

                command.Parameters.Add(new SqlParameter("PostalCode", SqlDbType.NVarChar));
                command.Parameters["PostalCode"].Value = txtPos.Text;



                conn.Open();
                command.ExecuteNonQuery();

                MessageBox.Show("Your Details have been Succesfuly added");




            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex);

            }
            finally
            {
                conn.Close();
            }
        }

        private void btnSign_Click(object sender, EventArgs e)
        {
            Hide();
            Form5 f5 = new Form5();
            f5.Show();
        }

        void FilldataGridView5()
        {
            if (conn.State == ConnectionState.Closed)
                conn.Open();
            SqlDataAdapter sqlda = new SqlDataAdapter("searchCustomer", conn);

            sqlda.SelectCommand.CommandType = CommandType.StoredProcedure;

            sqlda.SelectCommand.Parameters.AddWithValue("@Name", txtS3.Text.Trim());


            DataTable tbl = new DataTable();
            sqlda.Fill(tbl);

            dataGridView5.DataSource = tbl;
            //dataGridView1.Columns[0].Visible = true;

            conn.Close();

        }


        private void button3_Click(object sender, EventArgs e)
        {

            try
            {
                FilldataGridView5();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error message");

            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            /*   SqlConnection conn = new SqlConnection(@"server = .\SQLEXPRESS; database = LMS; Integrated Security = true");

         try
         {
             conn.Open();
             using (SqlCommand cmd = new SqlCommand = "UPDATE customer SET customerId= Name=@Name,Surname=@Surnamae,DOB=@DOB,postalCode=@postalCode WHERE " + "customerId=@customerId",conn))
        
             {
             cmd.Parameters.AddWithValue("@customerId",1);
             cmd.Parameters.AddWithValue("@Name",1);
             cmd.Parameters.AddWithValue("@customerId",1);
             cmd.Parameters.AddWithValue("@customerId",1);
             cmd.Parameters.AddWithValue("@customerId",1);
             

             SqlDataReader r = cmd.ExecuteReader();
             int a = 0;
             while (r.Read())
             {
                 a = 1;
             }

             if (a == 1)
             {


                   

                    
                MessageBox.Show("Successfully Signed In");
                Hide();
                 new Form3().Show();
             }
             else
             {
                 MessageBox.Show("Incorrect username or password");
             }



         }
         catch(Exception ex)
         {
             MessageBox.Show(""+ex);
         }
         finally
         {
             conn.Close();
         }
     }

     }

 }
*/
        }
    }
}
